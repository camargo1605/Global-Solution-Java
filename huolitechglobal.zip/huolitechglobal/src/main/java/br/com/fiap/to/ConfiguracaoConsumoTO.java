package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public class ConfiguracaoConsumoTO {

    private Long idConfiguracao;
    private Long idEletrodomestico;
    @NotNull @PositiveOrZero private Double limiteConsumo;
    @NotBlank private String acaoAposLimite;

    public ConfiguracaoConsumoTO() {
    }

    public ConfiguracaoConsumoTO(Long idConfiguracao, Long idEletrodomestico, @NotNull @PositiveOrZero Double limiteConsumo, @NotBlank String acaoAposLimite) {
        this.idConfiguracao = idConfiguracao;
        this.idEletrodomestico = idEletrodomestico;
        this.limiteConsumo = limiteConsumo;
        this.acaoAposLimite = acaoAposLimite;
    }

    public Long getIdConfiguracao() {
        return idConfiguracao;
    }

    public void setIdConfiguracao(Long idConfiguracao) {
        this.idConfiguracao = idConfiguracao;
    }

    public Long getIdEletrodomestico() {
        return idEletrodomestico;
    }

    public void setIdEletrodomestico(Long idEletrodomestico) {
        this.idEletrodomestico = idEletrodomestico;
    }

    public @NotNull @PositiveOrZero Double getLimiteConsumo() {
        return limiteConsumo;
    }

    public void setLimiteConsumo(@NotNull @PositiveOrZero Double limiteConsumo) {
        this.limiteConsumo = limiteConsumo;
    }

    public @NotBlank String getAcaoAposLimite() {
        return acaoAposLimite;
    }

    public void setAcaoAposLimite(@NotBlank String acaoAposLimite) {
        this.acaoAposLimite = acaoAposLimite;
    }
}