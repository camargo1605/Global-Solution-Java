package br.com.fiap.bo;

import br.com.fiap.dao.ConfiguracaoConsumoDAO;
import br.com.fiap.to.ConfiguracaoConsumoTO;

import java.util.ArrayList;

public class ConfiguracaoConsumoBO {

    private ConfiguracaoConsumoDAO configuracaoConsumoDAO;

    public ArrayList<ConfiguracaoConsumoTO> findAll(){
        configuracaoConsumoDAO = new ConfiguracaoConsumoDAO();
        return configuracaoConsumoDAO.findAll();
    }

    public ConfiguracaoConsumoTO findById(Long id) {
        configuracaoConsumoDAO = new ConfiguracaoConsumoDAO();
        return configuracaoConsumoDAO.findById(id);
    }

    public ConfiguracaoConsumoTO save(ConfiguracaoConsumoTO configuracaoConsumo) {
        configuracaoConsumoDAO = new ConfiguracaoConsumoDAO();
        return configuracaoConsumoDAO.save(configuracaoConsumo);
    }

    public boolean delete(Long id) {
        configuracaoConsumoDAO = new ConfiguracaoConsumoDAO();
        return configuracaoConsumoDAO.delete(id);
    }

    public ConfiguracaoConsumoTO update(ConfiguracaoConsumoTO configuracaoConsumo) {
        configuracaoConsumoDAO = new ConfiguracaoConsumoDAO();
        return configuracaoConsumoDAO.update(configuracaoConsumo);
    }
}
