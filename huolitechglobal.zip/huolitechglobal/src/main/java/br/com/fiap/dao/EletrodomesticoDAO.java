package br.com.fiap.dao;

import br.com.fiap.to.EletrodomesticoTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EletrodomesticoDAO extends Repository {

    public ArrayList<EletrodomesticoTO> findAll(){
        ArrayList<EletrodomesticoTO> eletrodomesticos = new ArrayList<EletrodomesticoTO>();
        String sql = "SELECT * FROM HUOLI_ELETRODOMESTICO ORDER BY idEletrodomestico";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ResultSet rs = ps.executeQuery();
            if (rs != null){
                while (rs.next()){
                    EletrodomesticoTO eletrodomestico = new EletrodomesticoTO();
                    eletrodomestico.setIdEletrodomestico(rs.getLong("idEletrodomestico"));
                    eletrodomestico.setNome(rs.getString("nome"));
                    eletrodomestico.setMarca(rs.getString("marca"));
                    eletrodomestico.setModelo(rs.getString("modelo"));
                    eletrodomestico.setPotencia(rs.getDouble("potencia"));
                    eletrodomestico.setVoltagem(rs.getString("voltagem"));
                    eletrodomestico.setTempoUso(rs.getDouble("tempoUso"));
                    eletrodomestico.setCustoEstimado(rs.getDouble("custoEstimado"));
                    eletrodomesticos.add(eletrodomestico);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar eletrodomesticos: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return eletrodomesticos;
    }

    public EletrodomesticoTO findById(Long id){
        EletrodomesticoTO eletrodomestico = new EletrodomesticoTO();
        String sql = "SELECT * FROM HUOLI_ELETRODOMESTICO WHERE idEletrodomestico = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                eletrodomestico.setIdEletrodomestico(rs.getLong("idEletrodomestico"));
                eletrodomestico.setNome(rs.getString("nome"));
                eletrodomestico.setMarca(rs.getString("marca"));
                eletrodomestico.setModelo(rs.getString("modelo"));
                eletrodomestico.setPotencia(rs.getDouble("potencia"));
                eletrodomestico.setVoltagem(rs.getString("voltagem"));
                eletrodomestico.setTempoUso(rs.getDouble("tempoUso"));
                eletrodomestico.setCustoEstimado(rs.getDouble("custoEstimado"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar eletrodomestico: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return eletrodomestico;
    }

    public EletrodomesticoTO save(EletrodomesticoTO eletrodomestico){
        String sql = "INSERT INTO HUOLI_ELETRODOMESTICO (idCliente, nome, marca, modelo, potencia, voltagem, tempoUso, custoEstimado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, eletrodomestico.getIdCliente());
            ps.setString(2, eletrodomestico.getNome());
            ps.setString(3, eletrodomestico.getMarca());
            ps.setString(4, eletrodomestico.getModelo());
            ps.setDouble(5, eletrodomestico.getPotencia());
            ps.setString(6, eletrodomestico.getVoltagem());
            ps.setDouble(7, eletrodomestico.getTempoUso());
            ps.setDouble(8, eletrodomestico.getCustoEstimado());
            if (ps.executeUpdate() > 0){
                return eletrodomestico;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao inserir eletrodomestico: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long id){
        String sql = "DELETE FROM HUOLI_ELETRODOMESTICO WHERE idEletrodomestico = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar eletrodomestico: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public EletrodomesticoTO update(EletrodomesticoTO eletrodomestico){
        String sql = "UPDATE HUOLI_ELETRODOMESTICO SET nome = ?, marca = ?, modelo = ?, potencia = ?, voltagem = ?, tempoUso = ?, custoEstimado = ? WHERE idEletrodomestico = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, eletrodomestico.getNome());
            ps.setString(2, eletrodomestico.getMarca());
            ps.setString(3, eletrodomestico.getModelo());
            ps.setDouble(4, eletrodomestico.getPotencia());
            ps.setString(5, eletrodomestico.getVoltagem());
            ps.setDouble(6, eletrodomestico.getTempoUso());
            ps.setDouble(7, eletrodomestico.getCustoEstimado());
            ps.setLong(8, eletrodomestico.getIdEletrodomestico());
            if (ps.executeUpdate() > 0){
                return eletrodomestico;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar eletrodomestico: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
