package br.com.fiap.bo;

import br.com.fiap.dao.EletrodomesticoDAO;
import br.com.fiap.to.EletrodomesticoTO;

import java.util.ArrayList;

public class EletrodomesticoBO {

    private EletrodomesticoDAO eletrodomesticoDAO;

    public ArrayList<EletrodomesticoTO> findAll() {
        eletrodomesticoDAO = new EletrodomesticoDAO();
        return eletrodomesticoDAO.findAll();
    }

    public EletrodomesticoTO findById(Long id) {
        eletrodomesticoDAO = new EletrodomesticoDAO();
        return eletrodomesticoDAO.findById(id);
    }

    public EletrodomesticoTO save (EletrodomesticoTO eletrodomestico) {
        eletrodomesticoDAO = new EletrodomesticoDAO();
        return eletrodomesticoDAO.save(eletrodomestico);
    }

    public boolean delete (Long id) {
        eletrodomesticoDAO = new EletrodomesticoDAO();
        return eletrodomesticoDAO.delete(id);
    }

    public EletrodomesticoTO update (EletrodomesticoTO eletrodomestico) {
        eletrodomesticoDAO = new EletrodomesticoDAO();
        return eletrodomesticoDAO.update(eletrodomestico);
    }
}
