package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public class EletrodomesticoTO {

    private Long idEletrodomestico;
    private Long idCliente;
    @NotBlank private String nome;
    @NotBlank private String marca;
    @NotBlank private String modelo;
    @NotNull @PositiveOrZero private Double potencia;
    @NotBlank private String voltagem;
    @NotNull @PositiveOrZero private Double tempoUso;
    @NotNull @PositiveOrZero private Double custoEstimado;

    public EletrodomesticoTO() {
    }

    public EletrodomesticoTO(Long idEletrodomestico, Long idCliente, @NotBlank String nome, @NotBlank String marca, @NotBlank String modelo, @NotNull @PositiveOrZero Double potencia, @NotBlank String voltagem, @NotNull @PositiveOrZero Double tempoUso, @NotNull @PositiveOrZero Double custoEstimado) {
        this.idEletrodomestico = idEletrodomestico;
        this.idCliente = idCliente;
        this.nome = nome;
        this.marca = marca;
        this.modelo = modelo;
        this.potencia = potencia;
        this.voltagem = voltagem;
        this.tempoUso = tempoUso;
        this.custoEstimado = custoEstimado;
    }

    public Long getIdEletrodomestico() {
        return idEletrodomestico;
    }

    public void setIdEletrodomestico(Long idEletrodomestico) {
        this.idEletrodomestico = idEletrodomestico;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Long idCliente) {
        this.idCliente = idCliente;
    }

    public @NotBlank String getNome() {
        return nome;
    }

    public void setNome(@NotBlank String nome) {
        this.nome = nome;
    }

    public @NotBlank String getMarca() {
        return marca;
    }

    public void setMarca(@NotBlank String marca) {
        this.marca = marca;
    }

    public @NotBlank String getModelo() {
        return modelo;
    }

    public void setModelo(@NotBlank String modelo) {
        this.modelo = modelo;
    }

    public @NotNull @PositiveOrZero Double getPotencia() {
        return potencia;
    }

    public void setPotencia(@NotNull @PositiveOrZero Double potencia) {
        this.potencia = potencia;
    }

    public @NotBlank String getVoltagem() {
        return voltagem;
    }

    public void setVoltagem(@NotBlank String voltagem) {
        this.voltagem = voltagem;
    }

    public @NotNull @PositiveOrZero Double getTempoUso() {
        return tempoUso;
    }

    public void setTempoUso(@NotNull @PositiveOrZero Double tempoUso) {
        this.tempoUso = tempoUso;
    }

    public @NotNull @PositiveOrZero Double getCustoEstimado() {
        return custoEstimado;
    }

    public void setCustoEstimado(@NotNull @PositiveOrZero Double custoEstimado) {
        this.custoEstimado = custoEstimado;
    }
}