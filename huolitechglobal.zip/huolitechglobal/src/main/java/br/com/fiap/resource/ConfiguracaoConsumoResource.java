package br.com.fiap.resource;


import br.com.fiap.bo.ConfiguracaoConsumoBO;
import br.com.fiap.to.ConfiguracaoConsumoTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;


@Path("/configuracaoConsumo")
public class ConfiguracaoConsumoResource {

    private ConfiguracaoConsumoBO configuracaoConsumoBO = new ConfiguracaoConsumoBO();

    @GET
    @Produces("application/json")
    public Response findAll() {
        ArrayList<ConfiguracaoConsumoTO> resultado = configuracaoConsumoBO.findAll();
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @GET
    @Path("/{id}")
    @Produces("application/json")
    public Response findById(@PathParam("id") Long id) {
        ConfiguracaoConsumoTO resultado = configuracaoConsumoBO.findById(id);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @POST
    @Consumes("application/json")
    public Response save(@Valid ConfiguracaoConsumoTO configuracao) {
        ConfiguracaoConsumoTO resultado = configuracaoConsumoBO.save(configuracao);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.created(null);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        Response.ResponseBuilder response = null;
        if (configuracaoConsumoBO.delete(id)) {
            response = Response.status(204);
        } else {
            response = Response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("/{id}")
    @Consumes("application/json")
    public Response update(@Valid ConfiguracaoConsumoTO configuracao, @PathParam("id") Long id) {
        ConfiguracaoConsumoTO resultado = configuracaoConsumoBO.update(configuracao);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.created(null);
        } else {
            response = Response.status(400);
        }
        response.entity(resultado);
        return response.build();
    }

}
