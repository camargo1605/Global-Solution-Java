package br.com.fiap.dao;

import br.com.fiap.to.ConfiguracaoConsumoTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ConfiguracaoConsumoDAO extends Repository{

    public ArrayList<ConfiguracaoConsumoTO> findAll() {
        ArrayList<ConfiguracaoConsumoTO> configuracoes = new ArrayList<ConfiguracaoConsumoTO>();
        String sql = "SELECT * FROM HUOLI_CONFIGURACAO_CONSUMO ORDER BY idConfiguracao";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    ConfiguracaoConsumoTO configuracao = new ConfiguracaoConsumoTO();
                    configuracao.setIdConfiguracao(rs.getLong("idConfiguracao"));
                    configuracao.setIdEletrodomestico(rs.getLong("idEletrodomestico"));
                    configuracao.setLimiteConsumo(rs.getDouble("limiteConsumo"));
                    configuracao.setAcaoAposLimite(rs.getString("acaoAposLimite"));
                    configuracoes.add(configuracao);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar configurações de consumo: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return configuracoes;
    }

    public ConfiguracaoConsumoTO findById(Long id) {
        ConfiguracaoConsumoTO configuracao = new ConfiguracaoConsumoTO();
        String sql = "SELECT * FROM HUOLI_CONFIGURACAO_CONSUMO WHERE idConfiguracao = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                configuracao.setIdConfiguracao(rs.getLong("idConfiguracao"));
                configuracao.setIdEletrodomestico(rs.getLong("idEletrodomestico"));
                configuracao.setLimiteConsumo(rs.getDouble("limiteConsumo"));
                configuracao.setAcaoAposLimite(rs.getString("acaoAposLimite"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar configuração de consumo: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return configuracao;
    }

    public ConfiguracaoConsumoTO save(ConfiguracaoConsumoTO configuracao) {
        String sql = "INSERT INTO HUOLI_CONFIGURACAO_CONSUMO (idEletrodomestico, limiteConsumo, acaoAposLimite) VALUES (?, ?, ?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, configuracao.getIdEletrodomestico());
            ps.setDouble(2, configuracao.getLimiteConsumo());
            ps.setString(3, configuracao.getAcaoAposLimite());
            if (ps.executeUpdate() > 0) {
                return configuracao;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao inserir configuração de consumo: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long id) {
        String sql = "DELETE FROM HUOLI_CONFIGURACAO_CONSUMO WHERE idConfiguracao = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar configuração de consumo: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public ConfiguracaoConsumoTO update(ConfiguracaoConsumoTO configuracao) {
        String sql = "UPDATE HUOLI_CONFIGURACAO_CONSUMO SET idEletrodomestico = ?, limiteConsumo = ?, acaoAposLimite = ? WHERE idConfiguracao = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, configuracao.getIdEletrodomestico());
            ps.setDouble(2, configuracao.getLimiteConsumo());
            ps.setString(3, configuracao.getAcaoAposLimite());
            ps.setLong(4, configuracao.getIdConfiguracao());
            if (ps.executeUpdate() > 0) {
                return configuracao;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar configuração de consumo: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

}
